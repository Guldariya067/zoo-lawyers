/* ===== ПРАВОВЫЕ ДАННЫЕ — редактируйте только после ручной проверки на adilet.zan.kz ===== */
const CHECKED_ON = null; // впишите дату своей ручной проверки, напр. "2026-11-20"; null = «Ожидает ручной проверки»
const LAW = 'https://adilet.zan.kz/rus/docs/Z2100000097';
const ACT = 'Закон РК «Об ответственном обращении с животными»', ACT_NO = 'от 30.12.2021 № 97-VII ЗРК';
const RULES = {
  keeping:  {act:ACT, no:ACT_NO, art:'ст. 21 «Требования при обращении и содержании домашних животных»', url:LAW, fine:null, verified:false},
  walking:  {act:ACT, no:ACT_NO, art:'ст. 22 «Требования к выгулу домашних животных»', url:LAW, fine:null, verified:false},
  cruelty:  {act:ACT, no:ACT_NO, art:'ст. 4 «Защита животных от жестокого обращения»', url:LAW, fine:null, verified:false},
  liability:{act:ACT, no:ACT_NO, art:'ст. 29 «Ответственность за нарушение законодательства…»', url:LAW, fine:null, verified:false}
};
/* Вопрос: opts = [текст, риск(0-2), «не знаю»(true/false)] */
const YN=[['Да',0],['Нет',2],['Не знаю',0,true]];
const ANIMAL=[['Собака',0],['Кошка',0],['Другое животное',1]];
const SC = {
 walk:{title:'Выгул собаки',icon:'🦮',rule:'walking',qs:[
  {id:'a',q:'Какое животное?',opts:ANIMAL},
  {id:'r',q:'В каком регионе Казахстана?',opts:[['Астана',0],['Алматы',0],['Шымкент',0],['Другой регион',1]]},
  {id:'p',q:'Где происходит выгул?',opts:[['Специальная площадка',0],['Двор / улица',1],['Детская или спортивная площадка',2],['Не знаю',0,true]]},
  {id:'l',q:'Собака на поводке (если нужен по местным правилам)?',opts:YN},
  {id:'c',q:'Убираете за собакой?',opts:[['Да',0],['Нет',2],['Иногда',1]]}],
  next:['Найдите местные правила выгула в акимате/МИО вашего города или области.','Выгуливайте на поводке и убирайте за животным — это снимает большинство конфликтов.','Избегайте детских и спортивных площадок.']},
 noise:{title:'Шум от животного',icon:'🔊',rule:'keeping',qs:[
  {id:'a',q:'Какое животное?',opts:ANIMAL},
  {id:'w',q:'Где возникла ситуация?',opts:[['Квартира в многоквартирном доме',1],['Частный дом',0],['Двор',1]]},
  {id:'h',q:'Что произошло?',opts:[['Лай/вой ночью',2],['Шум днём, периодически',1],['Единичный случай',0]]},
  {id:'k',q:'Есть жалоба соседей?',opts:[['Письменная / официальная',2],['Устная',1],['Нет',0],['Не знаю',0,true]]}],
  next:['Спокойно поговорите с соседями и выясните, когда шум мешает.','Проверьте причину: одиночество, скука, здоровье животного.','Если есть письменная жалоба — запросите её копию и сверьте факты.']},
 keeping:{title:'Содержание питомца в квартире',icon:'🏠',rule:'keeping',qs:[
  {id:'a',q:'Какое животное?',opts:ANIMAL},
  {id:'n',q:'Сколько животных (число от 1 до 50)?',type:'num',min:1,max:50},
  {id:'h',q:'Где живёте?',opts:[['Своя квартира',0],['Съёмная квартира',1],['Частный дом',0]]},
  {id:'v',q:'Есть ветеринарные документы / прививки?',opts:YN},
  {id:'s',q:'Условия содержания безопасны для соседей и животного?',opts:YN}],
  next:['Соблюдайте санитарные и ветеринарные требования.','Для съёмного жилья проверьте договор аренды.','Уточните, нет ли местных ограничений в вашем ОСИ/КСК.']},
 neighbors:{title:'Конфликт с соседями',icon:'🤝',rule:'keeping',qs:[
  {id:'t',q:'Суть конфликта?',opts:[['Шум',1],['Запах / чистота',1],['Места общего пользования',1],['Нападение / укус',2]]},
  {id:'d',q:'Пытались решить мирно?',opts:[['Да',0],['Нет',1]]},
  {id:'f',q:'Есть подтверждения (фото, видео, акт)?',opts:YN},
  {id:'o',q:'Обращались в КСК/ОСИ?',opts:[['Да',0],['Нет',0],['Не знаю',0,true]]}],
  next:['Зафиксируйте факты: даты, время, свидетели.','Предложите письменную договорённость.','При укусе обратитесь за медицинской помощью и сообщите в уполномоченные органы.']},
 complaint:{title:'Жалоба или возможное нарушение',icon:'📄',rule:'liability',qs:[
  {id:'w',q:'Кто обратился с жалобой?',opts:[['Сосед',1],['КСК / ОСИ',1],['Государственный орган',2],['Пока никто',0]]},
  {id:'f',q:'Жалоба в письменной форме?',opts:YN},
  {id:'e',q:'Вы согласны с описанными фактами?',opts:[['Да, всё верно',2],['Частично',1],['Нет',0],['Не знаю',0,true]]},
  {id:'p',q:'Есть протокол или предписание?',opts:[['Да',2],['Нет',0],['Не знаю',0,true]]}],
  next:['Запросите текст жалобы/документа и изучите, какая норма указана.','Соберите свои доказательства.','Сверьте норму и размер ответственности на adilet.zan.kz.']}
};
const STATUS=[
 ['s0','По проверенным условиям нарушение не выявлено'],
 ['s1','Обратите внимание на требования'],
 ['s2','Возможное нарушение'],
 ['s3','Недостаточно данных для вывода']];
function analyse(sc,ans){
  let risk=0,unk=0;
  sc.qs.forEach(q=>{
    if(q.type==='num'){ if(+ans[q.id]>=3) risk+=1; return; }
    const o=q.opts[ans[q.id]]; risk+=o[1]; if(o[2]) unk++;
  });
  if(unk>=2) return 3;
  if(risk>=4) return 2;
  if(risk>=2) return 1;
  return unk? 3 : 0;
}
/* ===== Справочник и ситуации ===== */
const TOPICS=[
 {t:'Содержание домашних животных',b:'Владелец отвечает за животное и условия его содержания. Конкретные обязанности смотрите в статье о требованиях при обращении и содержании домашних животных.',r:'keeping'},
 {t:'Выгул собак',b:'Требования к выгулу установлены законом, а детали (места, поводок) могут задаваться местными правилами. Не смешивайте правила разных регионов.',r:'walking'},
 {t:'Ответственность владельцев',b:'Закон содержит отдельную статью об ответственности. Размеры штрафов здесь не приводятся до ручной проверки.',r:'liability'},
 {t:'Обязанности по отношению к животным',b:'Закон защищает животных от жестокого обращения. Проверьте формулировки в соответствующей статье.',r:'cruelty'},
 {t:'Проживание в многоквартирном доме',b:'Помимо закона о животных действуют правила ОСИ/КСК и общие нормы. Конкретные положения требуют отдельной проверки.',r:'keeping'},
 {t:'Возможные административные нарушения',b:'Ответственность может быть предусмотрена КоАП РК. Статью и санкцию найдите и проверьте на adilet.zan.kz.',r:'liability'}];
const CASES=[
 {t:'Соседи жалуются на лай собаки',tag:'шум',sc:'noise',b:'Значение могут иметь время, частота шума и наличие жалоб. Мирные пути: разговор, причины лая, договорённость.'},
 {t:'Можно ли выгуливать собаку во дворе?',tag:'выгул',sc:'walk',b:'Ответ зависит от действующих правил и конкретного места (двор, площадка, улица).'},
 {t:'Конфликт из-за кошки в квартире',tag:'содержание',sc:'keeping',b:'У владельца есть права и обязанности по содержанию; важны условия, ветеринарные требования и правила дома.'},
 {t:'Что делать, если поступила жалоба?',tag:'жалоба',sc:'complaint',b:'Алгоритм: запросить документ → проверить факты → найти норму → сверить с источником → ответить письменно.'}];

const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function ruleHTML(k){const r=RULES[k];return `<p><b>${esc(r.act)}</b>, ${esc(r.no)}, ${esc(r.art)}.<br><a href="${r.url}" target="_blank" rel="noopener">Открыть на adilet.zan.kz</a></p>`+
 (r.verified?'':'<p class="warn">Требуется проверка актуальной редакции нормативного акта. Размер штрафа не указан — он не подтверждён.</p>');}

/* ===== Мастер ===== */
let cur=null,step=0,ans={};
function wiz(h){const w=$('#wiz');w.innerHTML='<div class="fade">'+h+'</div>';}
function start(){cur=null;step=0;ans={};
 wiz('<h3>Шаг 1. Выберите ситуацию</h3>'+Object.entries(SC).map(([k,s])=>`<button class="opt" data-k="${k}">${s.icon} ${s.title}</button>`).join(''));
 document.querySelectorAll('#wiz .opt').forEach(b=>b.onclick=()=>pick(b.dataset.k));}
function pick(k){cur=k;ans={};step=0;question();}
function question(){const sc=SC[cur],q=sc.qs[step],n=sc.qs.length;
 let body;
 if(q.type==='num') body=`<input id="num" type="number" inputmode="numeric" min="${q.min}" max="${q.max}" value="${ans[q.id]??''}">`;
 else body=q.opts.map((o,i)=>`<button class="opt ${ans[q.id]===i?'sel':''}" data-i="${i}">${o[0]}</button>`).join('');
 wiz(`<div class="bar"><i style="width:${(step/n)*100}%"></i></div><p class="muted">${sc.title} · вопрос ${step+1} из ${n}</p><h3>${q.q}</h3>${body}<p class="err" id="err" role="alert"></p>
 <div class="row"><button class="btn ghost" id="back">← Назад</button><button class="btn" id="next">${step+1===n?'Показать результат':'Далее'}</button></div>`);
 document.querySelectorAll('#wiz .opt').forEach(b=>b.onclick=()=>{ans[q.id]=+b.dataset.i;question();});
 $('#back').onclick=()=>{step===0?start():(step--,question());};
 $('#next').onclick=()=>{
  if(q.type==='num'){const raw=$('#num').value.trim();const v=Number(raw);
   if(raw==='') return err('Введите число.');
   if(!Number.isInteger(v)) return err('Нужно целое число.');
   if(v<q.min||v>q.max) return err(`Допустимо от ${q.min} до ${q.max}.`);
   ans[q.id]=v;
  } else if(ans[q.id]===undefined) return err('Выберите вариант ответа.');
  step++; step<n?question():result();};
}
function err(m){$('#err').textContent=m;}
function result(){const sc=SC[cur];
 for(const q of sc.qs) if(ans[q.id]===undefined) return err('Есть пропущенные ответы.');
 const st=analyse(sc,ans),[cls,label]=STATUS[st];markDone('sit',cur);
 wiz(`<div class="res"><div class="bar"><i style="width:100%"></i></div><div class="status ${cls}">${label}</div>
 <h3>${sc.title}</h3>
 <p>Это справочная подсказка по вашим ответам, а не юридическое заключение и не вывод о виновности.</p>
 <h4>Применимая норма</h4>${ruleHTML(sc.rule)}
 <h4>Рекомендации по результату</h4><ul>${TIPS[st].map(x=>`<li>${x}</li>`).join('')}</ul><h4>Что можно сделать дальше</h4><ul>${sc.next.map(x=>`<li>${x}</li>`).join('')}</ul>
 <div class="row noprint"><button class="btn" id="re">Начать заново</button><button class="btn ghost" id="ed">Изменить ответы</button><button class="btn ghost" id="pr">Скачать PDF (печать)</button></div></div>`);
 $('#re').onclick=start;$('#ed').onclick=()=>{step=0;question();};$('#pr').onclick=()=>printOnly('helper');}

/* ===== Справочник, ситуации, источники ===== */
function drawRules(f=''){const q=f.toLowerCase();
 const cats=['Все',...new Set(TOPICS.map(x=>x.c))];
 $('#ruleFilters').innerHTML=cats.map(c=>`<button class="opt chip${c===rc?' sel':''}" data-c="${c}">${c}</button>`).join('');
 const list=TOPICS.filter(x=>(rc==='Все'||x.c===rc)&&(x.t+x.b).toLowerCase().includes(q));
 $('#ruleList').innerHTML=list.length?list.map(x=>`<details class="rv" data-i="${TOPICS.indexOf(x)}"><summary>${x.t} <span class="tag">${x.c}</span></summary><p>${x.b}</p>${ruleHTML(x.r)}</details>`).join(''):'<p class="muted">Ничего не найдено.</p>';
 document.querySelectorAll('#ruleFilters .opt').forEach(b=>b.onclick=()=>{rc=b.dataset.c;drawRules($('#q').value);});
 reveal();}
let flt='все';
function drawCases(){const tags=['все',...new Set(CASES.map(c=>c.tag))];
 $('#filters').innerHTML=tags.map(t=>`<button class="opt" style="width:auto;margin:0;${t===flt?'background:var(--a);color:#123D35':''}" data-t="${t}">${t}</button>`).join('');
 $('#caseList').innerHTML=CASES.filter(c=>flt==='все'||c.tag===flt).map(c=>`<article class="card"><span class="tag">${c.tag}</span><h3>${c.t}</h3><p>${c.b}</p><button class="btn ghost" data-sc="${c.sc}">Проверить похожую ситуацию</button></article>`).join('');
 document.querySelectorAll('#filters .opt').forEach(b=>b.onclick=()=>{flt=b.dataset.t;drawCases();});
 bindSc();}
function bindSc(){document.querySelectorAll('[data-sc]').forEach(e=>e.onclick=()=>{pick(e.dataset.sc);$('#helper').scrollIntoView();});}
$('#q').oninput=e=>drawRules(e.target.value);
$('#checked').textContent=CHECKED_ON||'Ожидает ручной проверки';
$('#srcList').innerHTML='<ul>'+Object.values(RULES).map(r=>`<li>${esc(r.act)}, ${esc(r.no)}, ${esc(r.art)} — <a href="${r.url}" target="_blank" rel="noopener">adilet.zan.kz</a> · ${CHECKED_ON?'проверено '+CHECKED_ON:'ожидает ручной проверки'}</li>`).join('')+'<li>Кодекс РК об административных правонарушениях — статью и санкцию найдите самостоятельно на adilet.zan.kz · ожидает ручной проверки</li></ul>';

/* ===== Навигация, тема ===== */
$('#burger').onclick=()=>{const o=$('#nav').classList.toggle('open');$('#burger').setAttribute('aria-expanded',o);};
document.querySelectorAll('#nav a').forEach(a=>a.addEventListener('click',()=>$('#nav').classList.remove('open')));
if(matchMedia('(prefers-color-scheme: dark)').matches)document.documentElement.dataset.theme='dark';
$('#theme').onclick=()=>{const d=document.documentElement;d.dataset.theme=d.dataset.theme==='dark'?'light':'dark';};
const links=[...document.querySelectorAll('#nav a')];
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)links.forEach(l=>l.classList.toggle('on',l.getAttribute('href')==='#'+e.target.id));}),{rootMargin:'-40% 0px -55% 0px'});
['home','helper','practice','rules','cases','faq','sources'].forEach(id=>io.observe(document.getElementById(id)));
/* ===== РАСШИРЕНИЕ: ситуации, тренажёр, карта, генератор, FAQ, прогресс ===== */
Object.assign(SC,{
 bite:{title:'Укус или нападение животного',icon:'🐕',rule:'liability',qs:[
  {id:'w',q:'Кто пострадал?',opts:[['Человек',2],['Другое животное',1],['Никто, но была угроза',0]]},
  {id:'m',q:'Оказана ли медицинская или ветеринарная помощь?',opts:YN},
  {id:'f',q:'Есть подтверждения (фото, справки, свидетели)?',opts:YN},
  {id:'a',q:'Стороны уже связались друг с другом?',opts:[['Да, договорились',0],['Да, спор остался',1],['Нет',1]]}],
  next:['Сначала здоровье: помощь пострадавшему и осмотр у врача или ветеринара.','Сохраните справки, фото и контакты свидетелей.','Какая ответственность возможна — проверьте в тексте закона и на adilet.zan.kz.']},
 cruelty:{title:'Жестокое обращение с животным',icon:'⚠️',rule:'cruelty',qs:[
  {id:'r',q:'Вы наблюдатель или владелец животного?',opts:[['Наблюдатель',0],['Владелец',1]]},
  {id:'s',q:'Животному сейчас нужна срочная помощь?',opts:[['Да',2],['Нет',0],['Не знаю',0,true]]},
  {id:'e',q:'Есть фото или видео?',opts:YN},
  {id:'k',q:'Известны адрес или владелец животного?',opts:YN}],
  next:['Если животному нужна срочная помощь — обратитесь к ветеринару.','Зафиксируйте дату, место и обстоятельства, сохраните фото и видео.','Закон защищает животных от жестокого обращения: сверьтесь со статьёй и уточните, куда обратиться, в вашем регионе.']},
 rent:{title:'Питомец и съёмное жильё',icon:'🔑',rule:'keeping',qs:[
  {id:'a',q:'Какое животное?',opts:ANIMAL},
  {id:'c',q:'Что сказано о животных в договоре аренды?',opts:[['Разрешено',0],['Запрещено',2],['Ничего не сказано',1],['Не знаю',0,true]]},
  {id:'l',q:'Согласовали питомца с арендодателем?',opts:[['Да, письменно',0],['Да, устно',1],['Нет',2]]},
  {id:'v',q:'Есть ветеринарные документы?',opts:YN}],
  next:['Перечитайте договор аренды и условия о животных.','Получите согласие арендодателя в письменной форме.','Держите ветеринарные документы под рукой.']}
});
const TIPS=[
 ['Продолжайте соблюдать требования и храните документы на животное.','Время от времени сверяйте местные правила на сайте акимата.'],
 ['Устраните спорные моменты заранее: поговорите с соседями, уберите причину конфликта.','Уточните местные правила и правила вашего дома.'],
 ['Не спорьте на эмоциях: соберите факты и документы.','Сверьте нормы на adilet.zan.kz; при необходимости обратитесь к юристу.'],
 ['Часть ответов была «Не знаю» — выясните недостающие сведения.','Затем пройдите опрос ещё раз, чтобы результат стал точнее.']];
const CATS=['Содержание','Выгул','Ответственность','Права и обязанности','Содержание','Ответственность'];
CATS.forEach((c,i)=>TOPICS[i].c=c);
TOPICS.push(
 {t:'Права владельца',c:'Права и обязанности',r:'keeping',b:'Владелец вправе содержать домашнее животное, соблюдая требования закона и правила проживания. Перечень прав и ограничений смотрите в тексте закона: здесь он не приводится до ручной проверки.'},
 {t:'Обязанности при содержании',c:'Права и обязанности',r:'keeping',b:'Обязанности владельца связаны с безопасностью, санитарными и ветеринарными требованиями и защитой животного. Точный перечень — в статьях закона.'},
 {t:'Правила выгула в вашем городе',c:'Выгул',r:'walking',b:'Места выгула и требования к поводку могут определяться местными актами. Найдите их на сайте акимата или МИО вашего города.'},
 {t:'Жестокое обращение с животными',c:'Ответственность',r:'cruelty',b:'Закон защищает животных от жестокого обращения. Какая ответственность предусмотрена, проверьте в законе и КоАП РК на adilet.zan.kz.'});
let rc='Все';

/* Прогресс (localStorage, без личных данных) */
const KEY='zoo-progress-v1';
let P={};try{P=JSON.parse(localStorage.getItem(KEY))||{};}catch(e){}
['sit','sim','top'].forEach(k=>{if(!Array.isArray(P[k]))P[k]=[];});
function markDone(k,v){if(!P[k].includes(v)){P[k].push(v);try{localStorage.setItem(KEY,JSON.stringify(P));}catch(e){}}drawProg();}
function drawProg(){
 const rows=[['Ситуаций разобрано','sit',Object.keys(SC).length],['Сценариев пройдено','sim',SIM.length],['Тем изучено','top',TOPICS.length]];
 $('#prog').innerHTML=rows.map(([t,k,n])=>`<div class="pg"><div class="prh"><span>${t}</span><b>${P[k].length} / ${n}</b></div><div class="bar"><i style="width:${P[k].length/n*100}%"></i></div></div>`).join('')
 +`<p class="muted">Изученные темы: ${P.top.length?P.top.map(i=>esc(TOPICS[i]?TOPICS[i].t:'')).join(', '):'пока нет — откройте карточки в разделе «Законы».'}</p><div class="row noprint"><button class="btn ghost" id="prr">Сбросить прогресс</button></div>`;
 $('#prr').onclick=()=>{P={sit:[],sim:[],top:[]};try{localStorage.removeItem(KEY);}catch(e){}drawProg();};}

/* Печать только нужного блока */
function printOnly(k){document.body.dataset.p=k;window.print();}
addEventListener('afterprint',()=>{delete document.body.dataset.p;});

/* Появление карточек */
const rio=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');rio.unobserve(e.target);}}),{threshold:.1});
function reveal(){document.querySelectorAll('.card:not(.rv),details:not(.rv)').forEach(e=>e.classList.add('rv'));document.querySelectorAll('.rv:not(.in)').forEach(e=>rio.observe(e));}

/* Счётчики на главной: считают содержимое сайта */
function counters(){const v={s:Object.keys(SC).length,m:SIM.length,t:TOPICS.length,f:FAQ.length};
 document.querySelectorAll('[data-n]').forEach(el=>{const to=v[el.dataset.n];
  const run=()=>{if(matchMedia('(prefers-reduced-motion:reduce)').matches){el.textContent=to;return;}
   const t0=performance.now();(function f(t){const p=Math.min((t-t0)/900,1);el.textContent=Math.round(to*p);if(p<1)requestAnimationFrame(f);})(t0);};
  const o=new IntersectionObserver(es=>{if(es[0].isIntersecting){run();o.disconnect();}});o.observe(el);});}

/* Карточки законов */
$('#lawCards').innerHTML=Object.values(RULES).map(r=>`<article class="card"><span class="tag">${CHECKED_ON?'проверено':'не проверено'}</span><h3>${esc(r.art)}</h3><p class="muted">${esc(r.act)}, ${esc(r.no)}</p><a href="${r.url}" target="_blank" rel="noopener">Открыть на adilet.zan.kz</a></article>`).join('');
$('#ruleList').addEventListener('toggle',e=>{if(e.target.open&&e.target.dataset.i)markDone('top',+e.target.dataset.i);},true);

/* Тренажёр «Что бы вы сделали?» */
const V=['Лучше избегать','Допустимо, но есть риски','Мирный и законный путь'];
const SIM=[
{q:'Сосед жалуется, что ваша собака громко лает. Как поступить?',o:[
 ['Сказать, что собаке не запретишь лаять, и закрыть дверь',0,'Так конфликт обычно растёт, а жалоба может стать письменной и официальной.'],
 ['Узнать, когда именно шумит собака, и спокойно договориться с соседом',2,'Вы выясняете факты, ищете причину лая и показываете готовность решить вопрос — самый мирный путь.'],
 ['Написать на соседа встречную жалобу',1,'Спор обостряется. Претензии уместны, если есть факты, но сначала лучше поговорить.']]},
{q:'Вы гуляете с собакой во дворе без поводка: «она же добрая». Что верно?',o:[
 ['Гулять без поводка, пока никто не возражает',0,'Поведение животного может быть непредсказуемым, а правила могут требовать поводок. Проверьте нормы своего региона.'],
 ['Гулять только тогда, когда во дворе никого нет',1,'Конфликтов меньше, но правила это не отменяет: проверьте местные требования.'],
 ['Проверить местные правила, выгуливать на поводке и убирать за собакой',2,'Закон устанавливает требования к выгулу, а детали могут задавать местные правила. Поводок и уборка снимают большинство конфликтов.']]},
{q:'Вам пришла письменная жалоба от КСК/ОСИ на содержание питомца. Ваши действия?',o:[
 ['Запросить текст жалобы, проверить факты и указанную норму, ответить письменно',2,'Вы опираетесь на факты и документы, а ответ остаётся у вас на руках.'],
 ['Выбросить письмо — это не страшно',0,'Игнорирование не снимает вопрос. Лучше изучить документ и ответить.'],
 ['Позвонить и сразу всё признать, не читая жалобу',1,'Желание договориться хорошо, но признавать факты стоит после проверки.']]},
{q:'Соседям не нравится запах из квартиры, где живёт кошка. Что делать?',o:[
 ['Ответить, что это ваше личное дело',0,'Содержание животных связано с правилами и санитарными требованиями, а отказ от диалога усиливает конфликт.'],
 ['Сразу отдать кошку, не разбираясь',1,'Крайняя мера, обычно лишняя. Сначала устраните причину конфликта.'],
 ['Выяснить причину (лоток, уборка), устранить её и сообщить соседям',2,'Вы решаете причину проблемы и показываете готовность к диалогу.']]},
{q:'Во дворе вы нашли ухоженную собаку без хозяина. Что сделать в первую очередь?',o:[
 ['Сразу оставить себе, не ища владельца',1,'У собаки может быть хозяин. Сначала попробуйте его найти.'],
 ['Осмотреть ошейник и бирку, спросить соседей, повесить объявление, при необходимости показать ветеринару',2,'Вы заботитесь о животном и даёте владельцу шанс найтись.'],
 ['Прогнать её со двора',0,'Животное может пострадать, а вопрос не решится.']]},
{q:'На прогулке ваша собака укусила прохожего. С чего начать?',o:[
 ['Уйти, пока никто не заметил',0,'Это ухудшает ситуацию, а пострадавшему может быть нужна помощь.'],
 ['Помочь обратиться за медицинской помощью, обменяться контактами, зафиксировать обстоятельства',2,'Здоровье человека важнее всего, а контакты и факты пригодятся для дальнейшего урегулирования.'],
 ['Спорить о том, кто виноват',1,'Сначала помощь пострадавшему, споры потом.']]}];
let si=0,score=0;
function sim(){
 if(si>=SIM.length){$('#sim').innerHTML=`<div class="fade"><div class="bar"><i style="width:100%"></i></div><h3>Тренажёр пройден</h3><p>Мирных и законных вариантов выбрано: ${score} из ${SIM.length}. Это учебная оценка, а не юридический вывод.</p><button class="btn" id="sre">Пройти заново</button></div>`;
  $('#sre').onclick=()=>{si=0;score=0;sim();};return;}
 const s=SIM[si];
 $('#sim').innerHTML=`<div class="fade"><div class="bar"><i style="width:${si/SIM.length*100}%"></i></div><p class="muted">Сценарий ${si+1} из ${SIM.length}</p><h3>${s.q}</h3>`+s.o.map((o,i)=>`<button class="opt" data-i="${i}">${o[0]}</button>`).join('')+'<div id="sfb" aria-live="polite"></div></div>';
 document.querySelectorAll('#sim .opt').forEach(b=>b.onclick=()=>{
  const o=s.o[+b.dataset.i];if(o[1]===2)score++;markDone('sim',si);
  document.querySelectorAll('#sim .opt').forEach(x=>x.disabled=true);b.classList.add('sel');
  $('#sfb').innerHTML=`<div class="status s${2-o[1]}">${V[o[1]]}</div><p>${o[2]}</p><button class="btn" id="snx">${si+1<SIM.length?'Следующий сценарий':'Показать итог'}</button>`;
  $('#snx').onclick=()=>{si++;sim();};});}

/* Карта решений: Проблема → Вопросы → Действия → Результат */
let mk='walk';
function drawMap(){
 $('#mapSel').innerHTML=Object.entries(SC).map(([k,s])=>`<button class="opt chip${k===mk?' sel':''}" data-k="${k}">${s.icon} ${s.title}</button>`).join('');
 const s=SC[mk],r=RULES[s.rule],ul=a=>'<ul>'+a.map(x=>`<li>${x}</li>`).join('')+'</ul>';
 $('#map').innerHTML=[['Проблема',`<p><b>${s.icon} ${s.title}</b></p>`],['Вопросы',ul(s.qs.map(q=>q.q))],['Возможные действия',ul(s.next)],
  ['Результат',`<p>Статус по ответам: от «${STATUS[0][1].toLowerCase()}» до «${STATUS[2][1].toLowerCase()}».</p><p class="muted">${esc(r.art)}</p><button class="btn ghost" data-sc="${mk}">Пройти опрос</button>`]]
  .map(([t,b])=>`<div class="mc"><h4>${t}</h4>${b}</div>`).join('');
 document.querySelectorAll('#mapSel .opt').forEach(b=>b.onclick=()=>{mk=b.dataset.k;drawMap();});
 bindSc();}

/* Генератор обращений */
const GT=['Шум от животного','Выгул и содержание питомца','Конфликт с соседями','Жестокое обращение с животным','Ответ на жалобу в мой адрес'];
function initGen(){
 $('#gt').innerHTML='<option value="">Выберите тип…</option>'+GT.map(t=>`<option>${t}</option>`).join('');
 $('#gmk').onclick=()=>{const t=$('#gt').value,c=$('#gc').value.trim(),d=$('#gd').value.trim(),r=$('#gr').value.trim(),e=$('#gerr');
  e.textContent=!t?'Выберите тип проблемы.':c.length<2?'Укажите город.':d.length<20?'Опишите ситуацию подробнее (не меньше 20 символов).':r.length<5?'Укажите желаемый результат.':'';
  if(e.textContent)return;
  $('#ltxt').textContent=['ОБРАЩЕНИЕ (ЧЕРНОВИК)','','Кому: [укажите адресата — проверьте, какой орган или организация компетентны в вашем случае]','От: [ФИО, адрес, контакты — заполните самостоятельно]','Город: '+c,'Дата: '+new Date().toLocaleDateString('ru-RU'),'','Тема: '+t,'','Описание ситуации:',d,'','Прошу: '+r,'','Приложения: [перечислите документы, фото, акты — при наличии]','','Подпись: ____________'].join('\n');
  $('#letter').hidden=false;$('#gok').textContent='';$('#letter').scrollIntoView({behavior:'smooth',block:'nearest'});};
 $('#gcp').onclick=async()=>{const x=$('#ltxt').textContent;
  try{await navigator.clipboard.writeText(x);$('#gok').textContent='Текст скопирован.';}
  catch(e){const r=document.createRange();r.selectNodeContents($('#ltxt'));const g=getSelection();g.removeAllRanges();g.addRange(r);$('#gok').textContent='Текст выделен — нажмите Ctrl+C.';}};
 $('#gpr').onclick=()=>printOnly('gen');}

/* FAQ и обратная связь */
const FEEDBACK_EMAIL=''; // впишите свой e-mail; пусто = демонстрационный режим
const FAQ=[
['Это официальный государственный сервис?','Нет. Это учебный проект, который даёт общую справочную информацию.'],
['Сайт даёт юридические консультации?','Нет. Результаты помощника — справочные подсказки, а не заключение юриста.'],
['Откуда взяты нормы?','Из Закона РК «Об ответственном обращении с животными». Ссылки ведут на adilet.zan.kz; пометки показывают, что ещё не проверено вручную.'],
['Почему здесь нет размеров штрафов?','Они не показываются, пока не проверены вручную по актуальной редакции на adilet.zan.kz.'],
['Правила выгула одинаковы по всей стране?','Не обязательно. Закон задаёт общие требования, а места и детали выгула могут определяться местными правилами. Проверьте их для своего города.'],
['Сосед жалуется на шум. С чего начать?','Спокойно поговорите, узнайте, когда именно шумит животное, и найдите причину. Затем зафиксируйте договорённость. Другие шаги покажут помощник и тренажёр.'],
['Как подготовить обращение?','Воспользуйтесь генератором обращений. Это шаблон: адресата и приложения вы заполняете сами и проверяете текст перед отправкой.'],
['Сайт собирает мои ответы?','Нет. Ответы помощника остаются в памяти страницы. Счётчики прогресса хранятся в localStorage вашего браузера и никуда не отправляются.'],
['Как проверить актуальность нормы?','Откройте акт на adilet.zan.kz, посмотрите актуальную редакцию и дату последних изменений.'],
['Нужно ли убирать за собакой?','Требования к выгулу смотрите в соответствующей статье закона и в местных правилах. Уборка — разумная практика, которая снижает конфликты.'],
['Что делать, если животное укусило человека?','Сначала помощь пострадавшему и осмотр у врача. Затем зафиксируйте обстоятельства и контакты. Об ответственности — по тексту закона и КоАП РК.'],
['Как сохранить результат помощника в PDF?','Нажмите «Скачать PDF (печать)» и в окне печати браузера выберите «Сохранить как PDF».'],
['Как сообщить об ошибке на сайте?','Через форму обратной связи ниже: она откроет ваше почтовое приложение с готовым письмом.']];
function drawFaq(f=''){const q=f.toLowerCase(),l=FAQ.filter(x=>(x[0]+x[1]).toLowerCase().includes(q));
 $('#faqList').innerHTML=l.length?l.map(x=>`<details class="rv"><summary>${x[0]}</summary><p>${x[1]}</p></details>`).join(''):'<p class="muted">Ничего не найдено. Задайте вопрос через форму ниже.</p>';reveal();}
$('#fq').oninput=e=>drawFaq(e.target.value);
$('#fb').onsubmit=e=>{e.preventDefault();
 const n=$('#fn').value.trim(),m=$('#fe').value.trim(),t=$('#fm').value.trim(),er=$('#ferr');
 er.textContent=n.length<2?'Введите имя (не меньше 2 символов).':!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(m)?'Введите корректный e-mail.':t.length<10?'Сообщение слишком короткое (не меньше 10 символов).':'';
 if(er.textContent)return;
 $('#fok').textContent=FEEDBACK_EMAIL?'Открываем почтовое приложение…':'Демонстрационный режим: адрес получателя не задан, письмо откроется без адресата.';
 location.href='mailto:'+FEEDBACK_EMAIL+'?subject='+encodeURIComponent('ЗОО-ЮРИСТ KZ: обратная связь')+'&body='+encodeURIComponent(t+'\n\nОт: '+n+' ('+m+')');};

start();drawRules();drawCases();bindSc();
drawProg();sim();drawMap();drawFaq();initGen();counters();reveal();

